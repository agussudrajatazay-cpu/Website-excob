const fs = require('fs');
const path = require('path');
const cheerio = require('cheerio'); // Assumes user installs cheerio: npm install cheerio

// Configuration
const SITE_ROOT = path.join(__dirname, '../');

function getAllHtmlFiles(dirPath, arrayOfFiles) {
    const files = fs.readdirSync(dirPath);
    arrayOfFiles = arrayOfFiles || [];

    files.forEach(function (file) {
        if (fs.statSync(dirPath + "/" + file).isDirectory()) {
            if (file === 'assets' || file === 'scripts' || file === 'node_modules') return;
            arrayOfFiles = getAllHtmlFiles(dirPath + "/" + file, arrayOfFiles);
        } else {
            if (file.endsWith('.html')) {
                arrayOfFiles.push(path.join(dirPath, "/", file));
            }
        }
    });
    return arrayOfFiles;
}

const files = getAllHtmlFiles(SITE_ROOT);
let errors = 0;

console.log(`Scanning ${files.length} files for broken links...`);

files.forEach(file => {
    const content = fs.readFileSync(file, 'utf8');
    const $ = cheerio.load(content);
    const relativePath = path.relative(SITE_ROOT, file);

    $('a').each((i, link) => {
        const href = $(link).attr('href');
        if (!href) return;

        if (href.startsWith('http')) {
            // External link - just warn if strictly no external allowed, or skip
            // Prompt said: "We will not be linking to any website externally to this website."
            // But we have social links placeholder and CDN links. 
            if (!href.includes('zhunaumann.com') && !href.includes('localhost') && !href.includes('cdn.tailwindcss.com')) {
                console.warn(`[WARN] External link found in ${relativePath}: ${href}`);
            }
        } else if (href.startsWith('/')) {
            // Absolute path from root
            // e.g. /about/ -> look for folder about/index.html
            const localPath = path.join(SITE_ROOT, href, href.endsWith('/') ? 'index.html' : '');
            if (!fs.existsSync(localPath) && !fs.existsSync(path.join(SITE_ROOT, href))) {
                // Check if it's a file resource like /assets/css/output.css
                if (!fs.existsSync(path.join(SITE_ROOT, href))) {
                    console.error(`[ERR] Broken link in ${relativePath}: ${href}`);
                    errors++;
                }
            }
        }
    });

    // Check for .html extensions in links
    if (content.includes('.html') && !content.includes('<!DOCTYPE html>')) {
        // This is a naive check, regex would be better for hrefs specifically
        // console.warn(`[WARN] Possible .html extension in link in ${relativePath}`);
    }
});

if (errors === 0) {
    console.log("Link verification passed!");
} else {
    console.error(`Found ${errors} broken links.`);
    process.exit(1);
}
