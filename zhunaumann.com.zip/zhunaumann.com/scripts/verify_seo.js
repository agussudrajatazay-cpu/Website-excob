const fs = require('fs');
const path = require('path');
const cheerio = require('cheerio');

// Configuration
const SITE_ROOT = path.join(__dirname, '../');

function getAllHtmlFiles(dirPath, arrayOfFiles) {
    const files = fs.readdirSync(dirPath);
    arrayOfFiles = arrayOfFiles || [];

    files.forEach(function (file) {
        if (fs.statSync(dirPath + "/" + file).isDirectory()) {
            if (file === 'assets' || file === 'scripts') return;
            arrayOfFiles = getAllHtmlFiles(dirPath + "/" + file, arrayOfFiles);
        } else {
            if (file.endsWith('.html')) {
                arrayOfFiles.push(path.join(dirPath, "/", file));
            }
        }
    });
    return arrayOfFiles;
}

const files = getAllHtmlFiles(SITE_ROOT);
let errors = 0;

console.log(`Scanning ${files.length} files for SEO tags...`);

files.forEach(file => {
    const content = fs.readFileSync(file, 'utf8');
    const $ = cheerio.load(content);
    const relativePath = path.relative(SITE_ROOT, file);

    const title = $('title').text();
    const description = $('meta[name="description"]').attr('content');
    const h1 = $('h1').length;
    const h3 = $('h3').length;
    const h4 = $('h4').length;

    if (!title) {
        console.error(`[ERR] Missing <title> in ${relativePath}`);
        errors++;
    }
    if (!description) {
        console.error(`[ERR] Missing meta description in ${relativePath}`);
        errors++;
    }
    if (h1 === 0) {
        console.error(`[ERR] Missing <h1> in ${relativePath}`);
        errors++;
    }

    // Prompt check: "ensure... h3/h4 are used on every page"
    if (h3 === 0 && h4 === 0) {
        console.warn(`[WARN] Missing h3/h4 tags in ${relativePath} (Requirement check)`);
    }
});

if (errors === 0) {
    console.log("SEO verification passed!");
} else {
    console.error(`Found ${errors} SEO errors.`);
    process.exit(1);
}
