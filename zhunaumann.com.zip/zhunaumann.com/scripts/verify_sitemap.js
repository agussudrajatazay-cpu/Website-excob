const fs = require('fs');
const path = require('path');
const xml2js = require('xml2js'); // Assumes npm install xml2js

const SITEMAP_PATH = path.join(__dirname, '../sitemap.xml');

if (!fs.existsSync(SITEMAP_PATH)) {
    console.error("sitemap.xml not found!");
    process.exit(1);
}

const xml = fs.readFileSync(SITEMAP_PATH, 'utf8');

xml2js.parseString(xml, (err, result) => {
    if (err) {
        console.error("Invalid XML in sitemap:", err);
        process.exit(1);
    }

    if (!result.urlset || !result.urlset.url) {
        console.error("Invalid sitemap structure");
        process.exit(1);
    }

    console.log(`Found ${result.urlset.url.length} URLs in sitemap.`);

    // Check if pages exist for each URL
    // This part requires mapping domain URL to local path, which is environment specific.
    // For now, valid XML is the primary check.
    console.log("Sitemap verification passed!");
});
