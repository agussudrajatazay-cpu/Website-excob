const fs = require('fs');
const path = require('path');

const dataRaw = fs.readFileSync('site_data.json', 'utf8');
const data = JSON.parse(dataRaw);
const domainData = data.domain_analysis;
const seoData = data.seo_revival_strategy;

// Helper to ensure directory exists
function ensureDir(filePath) {
    const dirname = path.dirname(filePath);
    if (fs.existsSync(dirname)) {
        return true;
    }
    ensureDir(dirname);
    fs.mkdirSync(dirname);
}

// Common Components using simple template strings
const head = (title, description, path = '') => `
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${title} | ${domainData.business_intelligence.name}</title>
    <meta name="description" content="${description}">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&family=Merriweather:ital,wght@0,300;0,400;1,400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/output.css">
    <link rel="canonical" href="https://zhunaumann.com/${path}">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        serif: ['Merriweather', 'serif'],
                    },
                    colors: {
                        brand: {
                            50: '#f0f9ff',
                            100: '#e0f2fe',
                            500: '#0ea5e9',
                            600: '#0284c7',
                            900: '#0c4a6e',
                        }
                    }
                }
            }
        }
    </script>
</head>
<body class="antialiased flex flex-col min-h-screen">
`;

const nav = () => `
<nav class="glass-nav">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16 items-center">
            <div class="flex-shrink-0 flex items-center">
                <a href="/" class="text-2xl font-serif font-bold text-slate-900 tracking-tight">Zhu<span class="text-brand-600">Naumann</span></a>
            </div>
            <div class="hidden sm:ml-6 sm:flex sm:space-x-8">
                <a href="/" class="border-transparent text-slate-500 hover:border-brand-500 hover:text-slate-900 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium transition-colors">Home</a>
                <a href="/about/" class="border-transparent text-slate-500 hover:border-brand-500 hover:text-slate-900 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium transition-colors">About</a>
                <a href="/work/" class="border-transparent text-slate-500 hover:border-brand-500 hover:text-slate-900 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium transition-colors">Work</a>
                <a href="/services/" class="border-transparent text-slate-500 hover:border-brand-500 hover:text-slate-900 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium transition-colors">Services</a>
                <a href="/blog/" class="border-transparent text-slate-500 hover:border-brand-500 hover:text-slate-900 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium transition-colors">Blog</a>
                <a href="/contact/" class="text-white bg-brand-600 hover:bg-brand-700 px-4 py-2 rounded-full text-sm font-medium transition-all shadow-md hover:shadow-lg transform hover:-translate-y-0.5">Contact</a>
            </div>
            <!-- Mobile menu button placeholder -->
            <div class="-mr-2 flex items-center sm:hidden">
                 <button type="button" class="inline-flex items-center justify-center p-2 rounded-md text-slate-400 hover:text-slate-500 hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-brand-500" aria-controls="mobile-menu" aria-expanded="false">
                    <span class="sr-only">Open main menu</span>
                    <svg class="block h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                    </svg>
                </button>
            </div>
        </div>
    </div>
</nav>
`;

const footer = () => `
<footer class="bg-slate-900 text-white mt-auto">
    <div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div class="col-span-1 md:col-span-1">
                <span class="text-2xl font-serif font-bold tracking-tight">Zhu<span class="text-brand-500">Naumann</span></span>
                <p class="mt-4 text-slate-400 text-sm">
                    ${domainData.business_intelligence.description}
                </p>
            </div>
            <div>
                <h3 class="text-sm font-semibold text-slate-200 tracking-wider uppercase mb-4">Sitemap</h3>
                <ul class="space-y-3">
                    <li><a href="/" class="text-slate-400 hover:text-white transition-colors">Home</a></li>
                    <li><a href="/about/" class="text-slate-400 hover:text-white transition-colors">About</a></li>
                    <li><a href="/work/" class="text-slate-400 hover:text-white transition-colors">Work</a></li>
                    <li><a href="/services/" class="text-slate-400 hover:text-white transition-colors">Services</a></li>
                </ul>
            </div>
            <div>
                <h3 class="text-sm font-semibold text-slate-200 tracking-wider uppercase mb-4">Resources</h3>
                <ul class="space-y-3">
                    <li><a href="/blog/" class="text-slate-400 hover:text-white transition-colors">Blog</a></li>
                    <li><a href="/contact/" class="text-slate-400 hover:text-white transition-colors">Contact</a></li>
                    <li><a href="#" class="text-slate-400 hover:text-white transition-colors">Privacy Policy</a></li>
                    <li><a href="#" class="text-slate-400 hover:text-white transition-colors">Imprint</a></li>
                </ul>
            </div>
            <div>
                <h3 class="text-sm font-semibold text-slate-200 tracking-wider uppercase mb-4">Connect</h3>
                <p class="text-slate-400 text-sm mb-4">
                    ${domainData.ownership_intelligence.whois_data.registrant_email}
                </p>
                <div class="flex space-x-6">
                    <!-- Social icons would go here -->
                </div>
            </div>
        </div>
        <div class="mt-12 border-t border-slate-800 pt-8">
            <p class="text-base text-slate-400 text-center">
                &copy; ${new Date().getFullYear()} Zhu Naumann. All rights reserved.
            </p>
        </div>
    </div>
</footer>
</body>
</html>
`;

// GENERATORS
const generateHome = () => {
    const content = `
    ${head("Home", "Zhu Naumann - Professional Portfolio & Consultant")}
    ${nav()}
    <main>
        <!-- Hero Section -->
        <section class="relative bg-slate-50 pt-20 pb-20 lg:pt-32 lg:pb-28 overflow-hidden">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
                <div class="lg:grid lg:grid-cols-12 lg:gap-8 items-center">
                    <div class="sm:text-center md:max-w-2xl md:mx-auto lg:col-span-6 lg:text-left">
                        <h1 class="text-4xl tracking-tight font-extrabold text-slate-900 sm:text-5xl md:text-6xl lg:text-5xl xl:text-6xl">
                            <span class="block xl:inline">Crafting Digital</span>
                            <span class="block text-brand-600 xl:inline">Excellence</span>
                        </h1>
                        <p class="mt-3 text-base text-slate-500 sm:mt-5 sm:text-lg sm:max-w-xl sm:mx-auto md:mt-5 md:text-xl lg:mx-0">
                            Professional freelance services in design, development, and consulting. I help businesses transform ideas into impactful digital reality.
                        </p>
                        <div class="mt-8 sm:max-w-lg sm:mx-auto sm:text-center lg:text-left lg:mx-0">
                            <div class="space-x-4">
                                <a href="/work/" class="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-full shadow-sm text-white bg-brand-600 hover:bg-brand-700 transition-all">
                                    View Work
                                </a>
                                <a href="/contact/" class="inline-flex items-center px-6 py-3 border border-slate-300 text-base font-medium rounded-full text-slate-700 bg-white hover:bg-slate-50 transition-all">
                                    Contact Me
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="mt-12 relative sm:max-w-lg sm:mx-auto lg:mt-0 lg:max-w-none lg:mx-0 lg:col-span-6 lg:flex lg:items-center">
                         <div class="relative mx-auto w-full rounded-lg shadow-lg lg:max-w-md overflow-hidden transform rotate-2 hover:rotate-0 transition-transform duration-500">
                             <!-- Placeholder image generated via code or asset -->
                             <div class="bg-gradient-to-br from-brand-400 to-indigo-600 h-96 w-full flex items-center justify-center text-white text-2xl font-bold">
                                 Zhu Naumann
                             </div>
                         </div>
                    </div>
                </div>
            </div>
        </section>
        
        <!-- Services Preview -->
        <section class="py-16 bg-white">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="text-center">
                    <h2 class="text-3xl font-extrabold text-slate-900 sm:text-4xl">Expertise & Services</h2>
                    <p class="mt-4 max-w-2xl text-xl text-slate-500 mx-auto">
                        Delivering high-quality solutions tailored to your specific needs.
                    </p>
                </div>
                <div class="mt-12 grid gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
                    ${domainData.business_intelligence.services.slice(0, 3).map(service => `
                    <div class="bg-slate-50 rounded-xl p-8 hover:shadow-xl transition-shadow border border-slate-100">
                        <div class="w-12 h-12 bg-brand-100 text-brand-600 rounded-lg flex items-center justify-center mb-6">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
                        </div>
                        <h3 class="text-xl font-bold text-slate-900 mb-2">${service}</h3>
                        <p class="text-slate-500">Professional ${service.toLowerCase()} services designed to achieve your business goals.</p>
                        <a href="/services/" class="mt-4 inline-flex items-center text-brand-600 hover:text-brand-700 font-medium">Learn more &rarr;</a>
                    </div>
                    `).join('')}
                </div>
            </div>
        </section>
    </main>
    ${footer()}
    `;
    fs.writeFileSync('index.html', content);
};

const generateAbout = () => {
    const content = `
    ${head("About", "About Zhu Naumann - Professional Background")}
    ${nav()}
    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div class="max-w-3xl mx-auto">
            <h1 class="text-4xl font-bold text-slate-900 mb-6">About Me</h1>
            <div class="prose prose-lg prose-slate text-slate-600">
                <p class="lead text-xl text-slate-500 mb-8">
                    ${domainData.business_intelligence.description}
                </p>
                
                <h2 class="text-2xl font-bold text-slate-900 mt-12 mb-4">Professional Intelligence</h2>
                <div class="bg-slate-50 p-6 rounded-lg border border-slate-200 mb-8">
                    <ul class="space-y-4">
                        <li class="flex items-start">
                            <span class="font-bold text-slate-900 w-32">Confidence:</span>
                            <span>${(domainData.business_intelligence.confidence * 100).toFixed(0)}% Match</span>
                        </li>
                        <li class="flex items-start">
                            <span class="font-bold text-slate-900 w-32">Source:</span>
                            <span>${domainData.business_intelligence.source}</span>
                        </li>
                    </ul>
                </div>

                <h2 class="text-2xl font-bold text-slate-900 mt-12 mb-4">Timeline & Milestones</h2>
                <div class="border-l-4 border-brand-200 pl-8 space-y-10">
                    ${domainData.domain_timeline.business_milestones.map(m => `
                    <div class="relative">
                        <span class="absolute -left-11 top-1 h-6 w-6 rounded-full bg-brand-500 border-4 border-white"></span>
                        <h3 class="text-lg font-bold text-slate-900">${m.date}</h3>
                        <p class="text-slate-700 font-medium">${m.event}</p>
                        <p class="text-sm text-slate-500 mt-1">Confidence: ${m.confidence}</p>
                    </div>
                    `).join('')}
                </div>
            </div>
        </div>
    </main>
    ${footer()}
    `;
    ensureDir('about/index.html');
    fs.writeFileSync('about/index.html', content);
}

const generateWork = () => {
    const content = `
    ${head("Work & Projects", "Zhu Naumann Portfolio - Case Studies and Projects")}
    ${nav()}
    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div class="text-center mb-16">
            <h1 class="text-4xl font-bold text-slate-900 mb-4">Selected Work</h1>
            <p class="text-xl text-slate-500 max-w-2xl mx-auto">A showcase of projects demonstrating expertise in design, development, and consulting.</p>
        </div>

        <div class="grid gap-10 grid-cols-1 md:grid-cols-2">
            <!-- Dynamic project list would go here. Using placeholders for 'Inventory' requirement -->
            <div class="group relative bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all border border-slate-100">
                <div class="aspect-w-16 aspect-h-9 bg-slate-200 h-64 w-full object-cover">
                    <div class="h-full w-full flex items-center justify-center text-slate-400">
                        Project Preview
                    </div>
                </div>
                <div class="p-8">
                    <p class="text-sm font-medium text-brand-600 mb-2">Consulting • Strategy</p>
                    <h3 class="text-2xl font-bold text-slate-900 mb-3 group-hover:text-brand-600 transition-colors">Digital Transformation Roadmap</h3>
                    <p class="text-slate-500 mb-6">A comprehensive analysis and strategic roadmap for a mid-sized enterprise transitioning to modern digital workflows.</p>
                    <a href="#" class="inline-flex items-center text-slate-900 font-semibold hover:text-brand-600">View Case Study &rarr;</a>
                </div>
            </div>

             <div class="group relative bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all border border-slate-100">
                <div class="aspect-w-16 aspect-h-9 bg-slate-200 h-64 w-full object-cover">
                     <div class="h-full w-full flex items-center justify-center text-slate-400">
                        Project Preview
                    </div>
                </div>
                <div class="p-8">
                    <p class="text-sm font-medium text-brand-600 mb-2">Development • Design</p>
                    <h3 class="text-2xl font-bold text-slate-900 mb-3 group-hover:text-brand-600 transition-colors">E-Commerce Platform Redesign</h3>
                    <p class="text-slate-500 mb-6">Complete UX/UI overhaul and frontend implementation for a boutique fashion retailer.</p>
                    <a href="#" class="inline-flex items-center text-slate-900 font-semibold hover:text-brand-600">View Case Study &rarr;</a>
                </div>
            </div>
        </div>
    </main>
    ${footer()}
    `;
    ensureDir('work/index.html');
    fs.writeFileSync('work/index.html', content);
}

const generateServices = () => {
    const content = `
    ${head("Services", "Professional Services - Zhu Naumann")}
    ${nav()}
     <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div class="text-center mb-16">
             <h1 class="text-4xl font-bold text-slate-900 mb-4">Professional Services</h1>
             <p class="text-xl text-slate-500 max-w-2xl mx-auto">Tailored solutions for complex challenges.</p>
        </div>

        <div class="grid gap-8 grid-cols-1 md:grid-cols-3">
             ${domainData.business_intelligence.services.map(service => `
                 <div class="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 hover:border-brand-200 transition-colors">
                     <h3 class="text-xl font-bold text-slate-900 mb-4">${service}</h3>
                     <ul class="space-y-3 mb-8">
                         <li class="flex items-center text-slate-600">
                             <svg class="w-5 h-5 text-green-500 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                             Strategic Planning
                         </li>
                         <li class="flex items-center text-slate-600">
                             <svg class="w-5 h-5 text-green-500 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                             Implementation
                         </li>
                         <li class="flex items-center text-slate-600">
                             <svg class="w-5 h-5 text-green-500 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                             Review & Optimization
                         </li>
                     </ul>
                     <a href="/contact/" class="block w-full text-center py-3 px-4 border border-brand-600 text-brand-600 rounded-lg hover:bg-brand-50 transition-colors font-medium">Get a Quote</a>
                 </div>
             `).join('')}
        </div>
    </main>
    ${footer()}
    `;
    ensureDir('services/index.html');
    fs.writeFileSync('services/index.html', content);
}

const generateContact = () => {
    const content = `
    ${head("Contact", "Contact Zhu Naumann")}
    ${nav()}
    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div class="max-w-3xl mx-auto bg-white rounded-2xl shadow-xl overflow-hidden">
            <div class="grid grid-cols-1 md:grid-cols-2">
                <div class="p-10 bg-slate-900 text-white">
                    <h1 class="text-3xl font-bold mb-6">Let's talk</h1>
                    <p class="text-slate-300 mb-8">Ready to start your next project? Get in touch.</p>
                    
                    <div class="space-y-6">
                        <div class="flex items-start">
                            <svg class="w-6 h-6 text-brand-400 mt-1 mr-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
                            <div>
                                <span class="block text-sm font-medium text-slate-400">Email</span>
                                <a href="mailto:${domainData.ownership_intelligence.whois_data.registrant_email}" class="hover:text-white transition-colors">${domainData.ownership_intelligence.whois_data.registrant_email}</a>
                            </div>
                        </div>
                         <div class="flex items-start">
                            <svg class="w-6 h-6 text-brand-400 mt-1 mr-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg>
                            <div>
                                <span class="block text-sm font-medium text-slate-400">Phone</span>
                                <span class="block">${domainData.ownership_intelligence.whois_data.registrant_phone}</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="p-10 bg-white">
                    <form class="space-y-6">
                        <div>
                            <label for="name" class="block text-sm font-medium text-slate-700">Name</label>
                            <input type="text" id="name" name="name" class="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-brand-500 focus:ring-brand-500 sm:text-sm p-3 border">
                        </div>
                        <div>
                            <label for="email" class="block text-sm font-medium text-slate-700">Email</label>
                            <input type="email" id="email" name="email" class="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-brand-500 focus:ring-brand-500 sm:text-sm p-3 border">
                        </div>
                        <div>
                            <label for="message" class="block text-sm font-medium text-slate-700">Message</label>
                            <textarea id="message" name="message" rows="4" class="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-brand-500 focus:ring-brand-500 sm:text-sm p-3 border"></textarea>
                        </div>
                        <button type="submit" class="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-brand-600 hover:bg-brand-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-500 transition-colors">
                            Send Message
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </main>
    ${footer()}
    `;
    ensureDir('contact/index.html');
    fs.writeFileSync('contact/index.html', content);
}

const generateBlog = () => {
    const pillars = seoData.content_architecture.content_pillars;

    const content = `
    ${head("Blog & Insights", "Zhu Naumann Blog - Expertise and Insights")}
    ${nav()}
    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div class="text-center mb-16">
            <h1 class="text-4xl font-bold text-slate-900 mb-4">Insights</h1>
            <p class="text-xl text-slate-500 max-w-2xl mx-auto">Thoughts on design, technology, and the future of work.</p>
        </div>

        <div class="grid gap-12 lg:grid-cols-3 lg:gap-8">
            ${pillars.map(pillar => `
                <div class="flex flex-col">
                    <div class="mb-6">
                        <span class="inline-block px-3 py-1 rounded-full text-xs font-semibold tracking-wide uppercase bg-brand-100 text-brand-600">
                            ${pillar.pillar.split(' ')[0]}
                        </span>
                    </div>
                    ${pillar.clusters.slice(0, 3).map((topic, i) => `
                        <div class="mb-10 group cursor-pointer">
                            <h3 class="text-xl font-bold text-slate-900 mb-2 group-hover:text-brand-600 transition-colors">
                                <a href="#">${topic}</a>
                            </h3>
                            <p class="text-slate-500 text-base mb-4">
                                ${pillar.intent}. An exploration of key concepts and practical applications in this domain.
                            </p>
                            <div class="flex items-center text-sm text-slate-400">
                                <span class="flex items-center">
                                    <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                    5 min read
                                </span>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `).join('')}
        </div>
    </main>
    ${footer()}
    `;
    ensureDir('blog/index.html');
    fs.writeFileSync('blog/index.html', content);
}


// EXECUTE
try {
    generateHome();
    generateAbout();
    generateWork();
    generateServices();
    generateContact();
    generateBlog();
    console.log("Site generation complete.");
} catch (e) {
    console.error("Error generating site:", e);
}
