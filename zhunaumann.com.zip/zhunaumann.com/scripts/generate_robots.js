const fs = require('fs');

const content = `User-agent: *
Allow: /
Sitemap: https://zhunaumann.com/sitemap.xml
`;

fs.writeFileSync('robots.txt', content);
console.log('robots.txt generated');
